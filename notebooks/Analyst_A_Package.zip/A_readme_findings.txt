Analyst A — Descriptive Analytics
Generated on dataset: /mnt/data/Bank dataset.txt

Numeric summary saved to: visuals/numeric_summary.csv
Created visual files:
A_hist_age.png
A_bar_top10_jobs.png
A_bar_education.png
A_line_contacts_by_month.png
A_line_subrate_by_month.png
A_bar_subrate_by_contact.png
A_dist_job.png
A_dist_marital.png
A_dist_education.png
A_dist_contact.png
A_dist_poutcome.png
A_heatmap_numeric_corr.png